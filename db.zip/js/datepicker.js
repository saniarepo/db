$(document).ready(function(){
    $('#ticket-add-date').datepicker();
    $('#ticket-add-date').datepicker("option","dateFormat","yy-mm-dd");
    
});

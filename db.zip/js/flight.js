$('#flight-table tr').click(function(){
    var rowId = this.id;
    $('#data').load('modules/flight.php',{id:rowId});
});
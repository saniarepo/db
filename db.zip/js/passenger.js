$('#passenger-table tr').click(function(){
    var rowId = this.id;
    $('#data').load('modules/passenger.php',{id:rowId});
});
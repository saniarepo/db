<?php

require_once('db.func.php');

$id = ( isset( $_POST['id']) )? $_POST['id'] : 0;

$sql = 'SELECT * from passenger';
$array1 = dbGetQueryResult($sql);

?>
<h3>Пассажиры</h3>
<table id="passenger-table" class="table table-bordered table-striped">
<tr>
    <th>id</th>
    <th>Имя</th>
    <th>Фамилия</th>
    <th>Пол</th>
    <th>Возраст</th>
    <th>Паспорт</th>
</tr>
<?php foreach ( $array1 as $row1 ): if ( $id == 0 ) $id = $row1['id'];?>
    <tr <?php if($row1['id'] == $id) echo 'class="active"';?> id="<?=$row1['id']?>">
    <?php foreach ( $row1 as $key => $col ): ?>
        <td><?=$col?></td>
    <?php endforeach;?>
    </tr>
<?php endforeach;?>

</table>

<script type="text/javascript" src="js/passenger.js"></script>

<?php 
    $sql = "SELECT ticket.id,ticket.date_dep,flight.time_dep,flight.time_arr,flight.point_dep, flight.point_arr, flight.place FROM ticket, flight WHERE ticket.passenger=$id AND ticket.flight_id=flight.id";
    $array2 = dbGetQueryResult($sql);
?>

<h3>Билеты</h3>
<table class="table table-bordered table-striped">
<tr>
    <th>id</th>
    <th>Дата вылета</th>
    <th>Время вылета</th>
    <th>Время прилета</th>
    <th>Пункт отправления</th>
    <th>Пункт назначения</th>
    <th>Количество мест</th>
</tr>

<?php foreach ( $array2 as $row2 ): ?>
    <tr>
    <?php foreach ( $row2 as $col ): ?>
        <td><?=$col?></td>
    <?php endforeach;?>
    </tr>
<?php endforeach;?>

</table>
<?php
define('db_name','lab1');
define('db_user','root');
define('db_pass','root');
define('db_host','localhost');



<?php

require_once('db.func.php');

$id = ( isset( $_POST['id']) )? $_POST['id'] : 0;

$sql = 'SELECT * from flight';
$array1 = dbGetQueryResult($sql);

?>
<h3>Рейсы</h3>
<table id="flight-table" class="table table-bordered table-striped">
<tr>
    <th>id</th>
    <th>Время вылета</th>
    <th>Время прилета</th>
    <th>Пункт отправления</th>
    <th>Пункт назначения</th>
    <th>Количество мест</th>
</tr>
<?php foreach ( $array1 as $row1 ): if ( $id == 0 ) $id = $row1['id'];?>
    <tr <?php if($row1['id'] == $id) echo 'class="active"';?> id="<?=$row1['id']?>">
    <?php foreach ( $row1 as $col ): ?>
        <td><?=$col?></td>
    <?php endforeach;?>
    </tr>
<?php endforeach;?>

</table>

<script type="text/javascript" src="js/flight.js"></script>

<?php 
    $sql = "SELECT ticket.id,ticket.date_dep,passenger.name,passenger.lastname,passenger.sex, passenger.age,passenger.passport FROM passenger, ticket WHERE ticket.flight_id=$id AND ticket.passenger=passenger.id";
    $array2 = dbGetQueryResult($sql);
?>

<h3>Билеты</h3>
<table class="table table-bordered table-striped">
<tr>
    <th>id</th>
    <th>Дата вылета</th>
    <th>Имя</th>
    <th>Фамилия</th>
    <th>Пол</th>
    <th>Возраст</th>
    <th>Паспорт</th>
</tr>

<?php foreach ( $array2 as $row2 ): ?>
    <tr>
    <?php foreach ( $row2 as $col ): ?>
        <td><?=$col?></td>
    <?php endforeach;?>
    </tr>
<?php endforeach;?>

</table>